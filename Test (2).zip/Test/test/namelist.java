package test;
import java.awt.Label;
import java.util.regex.*;

public class namelist {

	public static void main(String[] args) {
		 outerloop:
			for(int i=0;i<10;i++) {

			innerloop:
				for(int j=0;j<10;j++) {
					
					
					if(j==5) {
					  break outerloop;
					}
					System.out.println(j);
				}


	}

}
}
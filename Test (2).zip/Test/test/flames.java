package test;

import java.util.*;
import java.util.Map.Entry;

public class flames {

	
	public static void main(String[] args) {
		Scanner scan=new Scanner(System.in);
		System.out.println("Enter the Name1 here:");
		String male=scan.nextLine().replaceAll(" ", "").toLowerCase();
		System.out.println("Enter the Name2 here:");
		String female=scan.nextLine().replaceAll(" ", "").toLowerCase();
		char[] male1=male.toCharArray();
		char[] female1=female.toCharArray();
		int remaining_character=0,i,j;
	    boolean oneElement=false;
		for(i=0;i<male1.length;i++) {
			
			for(j=0;j<female1.length;j++) {
				 
				if(male1[i]==female1[j])
				{
				   male1[i]='0';
				   female1[j]='0';

					break;
				}
			
			}
		}
		
		char[] result=new char[male1.length + female1.length];
		
		System.arraycopy(male1, 0, result, 0,male1.length);
		System.arraycopy(female1, 0, result, male1.length,female1.length );
	   
		for(char letter:result) {
			if(letter!='0') {
				remaining_character++;
			}
		}
		
		System.out.println("The Difference: "+ remaining_character);
		
//		HashSet<Integer> values=new HashSet<Integer>();
//		values.add(1);
//		values.add(2);
//		values.add(3);
//		
//		System.out.println(values);
//		
//		HashMap<Integer,String> map=new HashMap<Integer,String>();
//		map.put(1,"friends");
//		map.put(2,"love");
//		map.put(3,"affection");
//		map.put(4, "marriage");
//		map.put(5,"enemy");
//		map.put(6, "sister");
		
		ArrayList<String> list=new ArrayList<String>();
		list.add("friends"); 
		list.add("love");
		list.add("affection");
		list.add( "marriage");
		list.add("enemy");                   
		list.add( "sister");         
		
		
//		while(!oneElement)
//		{
//		for (Iterator<Entry<Integer, String>> iterator = map.entrySet().iterator(); iterator.hasNext();) {
//			Entry x = iterator.next();
//			  
//		if(map.size()==1) {
//			oneElement=true;
//		}
//				
//		}
//		}
		int count=0,n;
		
		if(remaining_character==0) {
			System.out.println("There is no match:");
			oneElement=true;
		}
		outerloop:
		while(!oneElement) {
			
			for(n=0;n<list.size();n++) {
				
				if(list.size()==1)
		       {
				oneElement=true;
			    break outerloop;
		        }
				count++;
				if(count==remaining_character) {
					list.remove(n);
					n--;
					count=0;
				}
			}
//			System.out.println(list);
	}
		if(remaining_character!=0) {
		System.out.println("Your result :" +list.get(0));
		}
		
		
	}

}

package test;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.function.BiFunction;
import java.util.stream.*;

public class StreamClassDemo {
	public static void main(String args[]) {
		List<Integer> list=Arrays.asList(8,2,3,4,2,1,0);
//		list.stream().toArray().forEach(System.out::println);
		
		
		///Comparator Method refrences
		
		
		/* in this sort method we need to implement the class and the metthod to sort instead we can use the s
		shorter form of code in the lambda Epression aND THE METHOD REFRENCE
		list.sort(new Comparator<Integer>(){

			@Override
			public int compare(Integer o1, Integer o2) {
				
				return o1.compareTo(o2);
			}
		
		}); */
		
		/* LAMBDA EXPRESSION
		 * list.sort((x,y)->x.compareTo(y));
		 */
		
		
		//method refrences
		
		list.sort(Integer::compareTo);
		
		
		//consumer function interface
		list.forEach(System.out::println);
		
		//lamba Expression
		list.forEach((x)-> System.out.println(x));
		
		
		
		
		
		//it consist of two input and one output so we using the bifunction interface
		BiFunction<Integer,Integer,Double> bifunction=StreamClassDemo::addNumbers;
		System.out.println(bifunction.apply(10,20));
	}
	public static double addNumbers(Integer i1,Integer i2) {
		return i1+i2;
	}

}

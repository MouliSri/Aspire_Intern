package test;

public class aspire {
    public static void main(String args[]) {
    	
    	Add add=new Add();
    	Sub sub=new Sub();
    	Maths math=new Maths(sub);
    	
    	math.run();
    	
    }
}

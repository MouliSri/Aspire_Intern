package Review2;

public class OwnException extends Exception {

	public OwnException(String string) {
	super(string);
	}

}

package oops;

public interface Interface1 {
	void add();
	
	default void Interface1() {
		System.out.println("im here no fear");
	}
	static void sub() {
		System.out.println("donee bruhhhhhhh");
	}
	
	
	
	public interface Interface2{
		
		void multiply();
		
	}

}



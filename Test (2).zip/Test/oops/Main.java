package oops;

public class Main {

	public static void main(String[] args) {
//		a1 a=new a1();
//		a.run();
//		a.sleep();
    implemted i=new implemted();
   
    i.add();
    i.multiply();
    i.sub();
   Interface1.sub();
 
   

	}

}

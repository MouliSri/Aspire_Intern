package oops;

 class PrivateClass {
	

}

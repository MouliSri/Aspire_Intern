package test;
interface i1{
	void m1();
}

interface i2{
	void m1();
}


public class inter implements i1,i2{
 public void m1() {
	 System.out.println("hello");
 }
 public static void main(String args[]) {
	 inter o=new inter();
	 o.m1();
 }
 
}

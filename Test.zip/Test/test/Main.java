package test;

public class Main {
	static int i=100;
	public static void run() {
		int j = 293;
		 System.out.println("im running here");
	}
	
	

	public static void main(String[] args) {
		
         Main.i=10000;
         a obj=new a();
         obj.run();
	}

}

class a extends Main{
   public static void run() {
		 System.out.println("seocnd");
	}
}

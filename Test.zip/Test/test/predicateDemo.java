package test;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Predicate;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class predicateDemo {

	public static void main(String[] args) {
		Movie movie1=new Movie();
		movie1.setName("Vijay");
		movie1.setYear(2022);
		movie1.setMovieName("Beast");
		
		Movie movie2=new Movie();
		movie2.setName("surya");
		movie2.setYear(2021);
		movie2.setMovieName("Jai Bhim");
		
		
		Movie movie3=new Movie();
		movie3.setName("Ajith");
		movie3.setYear(2020);
		movie3.setMovieName("valimai");
		
		
		
		ArrayList<Movie> list=new ArrayList<>();
	     list.add(movie1);
	     list.add(movie2);
	     list.add(movie3);
	     
	     
	     Stream<Movie> movieStream=list.stream();
	    
	     List<String> movie= movieStream.map((x)-> x.getMovieName()).collect(Collectors.toList());
	   
	     movie.forEach(System.out::println);
	     
	     
	     //predicate function interface
	     getMovies(list,x-> x.getName().equalsIgnoreCase("vijay"));
	}
	
	private static void getMovies(ArrayList<Movie> list,Predicate<Movie> predict){
	 for(Movie movie:list) {
	  if(predict.test(movie)) {
		  System.out.println(movie.getMovieName());
	  }
	 }
		
	}
	
	
	
	
	

}

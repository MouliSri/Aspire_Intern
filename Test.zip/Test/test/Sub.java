package test;

public class Sub implements operation{

	@Override
	public void value(int a, int b) {
		System.out.println(a-b);
		
	}

}

package test;

public class Maths {
	private operation opt;

	public Maths(operation opt) {
		this.opt=opt;
	}

	public void run() {
	
		 opt.value(10,20);
	}
	
   

}

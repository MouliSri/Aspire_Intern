package test;

public interface operation {
	
	void value(int a,int b);

}

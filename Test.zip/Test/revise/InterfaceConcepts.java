package revise;

import java.util.Arrays;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

public class InterfaceConcepts {

	public static void main(String[] args) {
		List<String> list=Arrays.asList("mouli","ravindar","emmanuel","hanita");  //source
        list.sort(String::compareToIgnoreCase);   //intermediate    compareTo 
        list.forEach(System.out::println);       //  terminal
        
        
        
	}

}

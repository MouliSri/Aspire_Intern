package Day1;

public class Polymorphism {

	public static void main(String[] args) {
		

	}

}

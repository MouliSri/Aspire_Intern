package Day1;

public class Inheritance {

}
